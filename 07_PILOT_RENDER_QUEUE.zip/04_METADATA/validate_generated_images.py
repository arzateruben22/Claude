from pathlib import Path
from PIL import Image
import json,hashlib
root=Path(__file__).resolve().parent.parent
shots=[json.loads(l) for l in (root/'04_METADATA/scene_manifest_3000.jsonl').read_text().splitlines()]
done=[];bad=[]
for s in shots:
 p=root/s['relative_output_path']
 if not p.exists():continue
 try:
  with Image.open(p) as im:
   w,h=im.size;im.verify()
  done.append({'id':s['id'],'size':[w,h],'native_4k': w>=3840 and h>=2160,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 except Exception as e:bad.append((s['id'],str(e)))
print(f"VALID GENERATED IMAGE FILES: {len(done)}/3000. NATIVE 4K DIMENSIONS: {sum(x['native_4k'] for x in done)}. BAD FILES: {len(bad)}")
(root/'04_METADATA/render_audit.json').write_text(json.dumps({'rendered':done,'bad':bad},indent=2))
